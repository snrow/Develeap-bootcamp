Doc
---

This archetype is based on the "Responsive Side Menu" layout provided by the 
purecss framework at http://purecss.io/layouts/ .


Structure
---------

The documentation is written as markdown files in the doc/ directory.

The files are then included by content/index.html.peb for generating a 
multi page doc and by content/single.html.peb for a single page doc.

The style+js are in static/*